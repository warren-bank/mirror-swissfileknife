/*
   Swiss File Knife Simple Expressions SDK V 1.0
   =============================================
   
   Includes:

      -  SFKMatch C++ class, the SFK Expression Parser

      -  XEd example tool to
         -  load a text or binary file
         -  apply /from/to/ pattern replacements
         -  write output to terminal or another file

   For simplest possible integration, the provided XEd code
   contains no color handling. The SFKMatch class is prepared
   to handle color attributes as well, see sfkmatch.hpp for details.

   How to compile:
   
      Windows: cl xed.cpp sfkmatch.cpp
      Linux  : g++ xed.cpp sfkmatch.cpp
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

#ifdef _WIN32
 #include <windows.h>
 #define vsnprintf _vsnprintf
 #define snprintf  _snprintf
 const char  glblPathChar = '\\';
#else
 const char  glblPathChar = '/';
#endif

#include "sfkmatch.hpp"

#define mymin(a,b) ((a<b)?(a):(b))

#define strcopy(dst,src) mystrcopy(dst,src,sizeof(dst)-10)

// copies a maximum of nMaxDst MINUS ONE chars,
// AND adds a zero terminator at pszDst (within nMaxDst range!).
// to use this like strncpy, always add +1 to nMaxDst.
// NOTE: if nMaxDst == 0, NO zero terminator is added.
void mystrcopy(char *pszDst, const char *pszSrc, int nMaxDst)
{
   if (nMaxDst < 2) {
      if (nMaxDst >= 1)
         pszDst[0] = '\0';
      return;
   }
   int nLen = strlen(pszSrc);
   if (nLen > nMaxDst-1)
      nLen = nMaxDst-1;
   memcpy(pszDst, pszSrc, nLen);
   pszDst[nLen] = '\0';
}

char *dataAsTrace(void *pAnyData, int iDataSize, char *pszBuf=0, int iMaxBuf=0)
{
   static char szBuf[300];

   if (!pszBuf)
   {
      pszBuf = szBuf;
      iMaxBuf = sizeof(szBuf);
   }
 
   uint8_t *pSrcCur = (uint8_t *)pAnyData;
   uint8_t *pSrcMax = pSrcCur + iDataSize;
 
   char *pszDstCur = pszBuf;
   char *pszDstMax = pszBuf + iMaxBuf - 20;
 
   while (pSrcCur < pSrcMax && pszDstCur < pszDstMax)
   {
      uint8_t uc = *pSrcCur++;
 
      if (isprint((char)uc))
      {
         *pszDstCur++ = (char)uc;
         continue;
      }

      // convert binary to {hex}
      sprintf(pszDstCur, "{%02X}", uc);
      pszDstCur += 4;
   }
 
   *pszDstCur = '\0';
 
   return pszBuf;
}

// current input file name
char szGlblCurrentInputFile[512+10];

int cbSFKMatchOutFN(int iFunction, char *pMask, int *pIOMaskLen, uint8_t **ppOut, int *pOutLen)
{
   static char szOutBuf[800];

   char szTmpBuf[800];

   int iCmd = 0;

   int iMaxLen = sizeof(szGlblCurrentInputFile)+100;

   if (!strncmp(pMask, "file.name", 9))      { iCmd=1; *pIOMaskLen=9;  } else
   if (!strncmp(pMask, "file.relname", 12))  { iCmd=2; *pIOMaskLen=12; }
   if (!strncmp(pMask, "file.path", 9))      { iCmd=3; *pIOMaskLen=9;  }
   if (!strncmp(pMask, "file.base", 9))      { iCmd=4; *pIOMaskLen=9;  }
   if (!strncmp(pMask, "file.ext" , 8))      { iCmd=5; *pIOMaskLen=8;  }

   if (!iCmd)
      return 11;

   if (iFunction==1) // check syntax
   {
      if (!pOutLen)
         return 10+sfkerr("missing outlen parameter for expression output function");
      *pOutLen = iMaxLen;
      return 0;
   }

   if (!ppOut)
      return 10+sfkerr("invalid parameters for expression output function");

   char *psz=0;

   switch (iCmd)
   {
      case 1:  // absname
         strcopy(szOutBuf, szGlblCurrentInputFile);
         break;
      case 2:  // relname
      {
         char *prel = strrchr(szGlblCurrentInputFile, glblPathChar);
         if (prel) {
            strcopy(szOutBuf, prel+1);
         } else {
            strcopy(szOutBuf, szGlblCurrentInputFile);
         }
         break;
      }
      case 3:  // path
      {
         strcopy(szOutBuf, szGlblCurrentInputFile);
         char *prel = strchr(szOutBuf, glblPathChar);
         if (prel) {
            *prel = '\0';
         } else {
            szOutBuf[0] = '\0';
         }
         break;
      }
      case 4:  // basename
      {
         // build relname
         char *prel = strrchr(szGlblCurrentInputFile, glblPathChar);
         if (prel) {
            strcopy(szOutBuf, prel+1);
         } else {
            strcopy(szOutBuf, szGlblCurrentInputFile);
         }
         // isolate basename
         if ((psz = strrchr(szOutBuf, '.')))
            *psz = '\0';
         break;
      }
      case 5:  // ext
      {
         // build relname
         char *prel = strrchr(szGlblCurrentInputFile, glblPathChar);
         if (prel) {
            strcopy(szTmpBuf, prel+1);
         } else {
            strcopy(szTmpBuf, szGlblCurrentInputFile);
         }
         // isolate extension
         if ((psz = strrchr(szTmpBuf, '.')))
            strcopy(szOutBuf, psz+1);
         else
            szOutBuf[0] = '\0';
         break;
      }
   }

   *ppOut = (uint8_t*)szOutBuf;
   *pOutLen = strlen(szOutBuf);
 
   return 0;
}

bool strBegins(char *pszStr, const char *pszPat) {
   if (!strncmp(pszStr, pszPat, strlen(pszPat)))
      return 1;
   return 0;
}

// process -opt=value AND -opt value
bool haveParmOption(char *argv[], int argc, int &iDir, const char *pszOptBase, char **pszOutParm)
{
   *pszOutParm = 0;  // if this stays NULL it tells ERROR status.

   // check if format -opt=value is given
   char szEqBuf[100];
   sprintf(szEqBuf, "%s=", pszOptBase);
   char *pszOpt = argv[iDir];
   if (*pszOpt == '+') pszOpt++; // e.g. +md5gento=
   if (!strncmp(pszOpt, szEqBuf, strlen(szEqBuf))) {
      *pszOutParm = pszOpt+strlen(szEqBuf);
      return 1;
   }

   // check if format "-opt value" is given
   if (!strcmp(pszOpt, pszOptBase)) {
      if (iDir >= argc-1) {
         sfkerr("missing parameter after option %s\n", pszOptBase);
         return 0;
      }
      iDir++;  // IDIR INCREMENT IS WRITTEN BACK!
      *pszOutParm = argv[iDir];
      return 1;
   }

   return 0;
}

struct MainOptions
{
   char placeholder;  //// for null bytes
   bool rawterm;      //// dump output as is
   bool showpre;      //// replace
   bool showpost;     //// replace
   bool showlist;     //// replace
   bool repDumpHalve; // replace: hexdump only source side
   char *tomask;      // output filename mask
   bool  tomaskfile;  // -to mask is a single filename
   int verbose   ;    // 0,1,2
   char szeol[10];    // crlf or lf
};

char szLineBuf[MAX_LINE_LEN+10];
char szAttrBuf[MAX_LINE_LEN+10];

int64_t getFileSizeSeek(char *pszName)
{
   FILE *fin = fopen(pszName, "rb");
   if (!fin) return -1;

   if (fseek(fin, 0, SEEK_END))
      { fclose(fin); return -1; }

   int64_t npos = (int64_t)ftell(fin);

   fclose(fin);

   return npos;
}

uint8_t *loadBinaryFile(char *pszFile, int64_t &rnFileSize)
{
   int64_t nFileSize = getFileSizeSeek(pszFile);
   if (nFileSize < 0)
      return 0;

   int64_t nTolerance = 10;
   char *pOut = new char[nFileSize+nTolerance+4];
   if (!pOut) {
      sfkerr("out of memory: %s\n", pszFile);
      return 0;
   }
   memset(pOut+nFileSize, 0, nTolerance); // added safety

   FILE *fin = fopen(pszFile, "rb");
   if (!fin) {
      sfkerr("cannot read: %s\n", pszFile);
      delete [] pOut;
      return 0;
   }

   int nRead = fread(pOut, 1, nFileSize, fin);
   fclose(fin);
   if (nRead != nFileSize) {
      sfkerr("cannot read: %s (%d %d)\n", pszFile, nRead, nFileSize);
      delete [] pOut;
      return 0;
   }

   // not strictly needed w/binary data, but anyway.
   pOut[nFileSize] = '\0';

   rnFileSize = nFileSize;
   return (uint8_t*)pOut;
}

#define SFK_IO_BLOCK_SIZE 10000000 // about 10 MB

// large block write incl. optional info update and checksum building
size_t myfwrite(uint8_t *pBuf, size_t nBytes, FILE *fout)
{
   size_t nOffset = 0;
   size_t nRemain = nBytes;

   while (nRemain > 0)
   {
      size_t nBlock = SFK_IO_BLOCK_SIZE;
      if (nBlock > nRemain) nBlock = nRemain;

      size_t nWriteSub = fwrite(pBuf+nOffset, 1, nBlock, fout);

      if (nWriteSub != nBlock)
         return nOffset+nWriteSub; // return no. of bytes actually written

      nOffset += nWriteSub;
      nRemain -= nWriteSub;
   }

   return nOffset;
}

int saveFile(char *pszName, uint8_t *pData, int iSize)
{
   FILE *fout = fopen(pszName, "wb");
   if (!fout)
      return 9+sfkerr("cannot write: %s\n", pszName);

   if (myfwrite(pData, iSize, fout) != iSize) {
      fclose(fout);
      return 10+sfkerr("cannot fully write (disk full?): %s\n", pszName);
   }

   fclose(fout);
   return 0;
}

char szPrintBufMap[MAX_LINE_LEN+10];

// without zero termination, only for short fixed-size strings
void mystrplot(char *pOut, int iMaxOut, const char *pszFormat, ...)
{
   va_list argList;
   va_start(argList, pszFormat);
   ::vsnprintf(szPrintBufMap, sizeof(szPrintBufMap)-10, pszFormat, argList);
   szPrintBufMap[sizeof(szPrintBufMap)-10] = '\0';
   char *psz = szPrintBufMap;

   int iCopy = strlen(psz);
   if (iCopy > iMaxOut)
      iCopy = iMaxOut;
 
   memcpy(pOut, psz, iCopy);
}

void mystrcatf(char *pOut, int nOutMax, const char *pszFormat, ...)
{
   va_list argList;
   va_start(argList, pszFormat);
   ::vsnprintf(szPrintBufMap, sizeof(szPrintBufMap)-10, pszFormat, argList);
   szPrintBufMap[sizeof(szPrintBufMap)-10] = '\0';
   char *psz = szPrintBufMap;

   if (nOutMax == 0) nOutMax = MAX_LINE_LEN;

   int nlen1 = strlen(pOut);
   int nrem1 = (nOutMax - nlen1) - 1; // including term.
   int nlen2 = strlen(psz);
   if (nlen2 > nrem1) nlen2 = nrem1;
   if (nlen2 > 0) {
      memcpy(pOut+nlen1, psz, nlen2);
      *(pOut+nlen1+nlen2) = '\0';
   }
}

bool bGlblHexDumpWide    = 0;
int nGlblHexDumpForm     = 0;
int64_t  nGlblHexDumpOff     = 0;
int64_t  nGlblHexDumpLen     = 0;

void removeCRLF(char *pszBuf) {
   char *pszLF = strchr(pszBuf, '\n');
   if (pszLF) *pszLF = '\0';
   char *pszCR = strchr(pszBuf, '\r');
   if (pszCR) *pszCR = '\0';
}

char *numtostr(int64_t n, int nDigits, char *pszBuf, int nRadix)
{
   static char szBuf[100];
   if (!pszBuf)
        pszBuf = szBuf;

   #ifdef _WIN32
   if (nRadix == 10)
      sprintf(pszBuf, "%0*I64d", nDigits, n);
   else
      sprintf(pszBuf, "%0*I64X", nDigits, n);
   return pszBuf;
   #else
   if (nRadix == 10)
      sprintf(pszBuf, "%0*lld", nDigits, n);
   else
      sprintf(pszBuf, "%0*llX", nDigits, n);
   return pszBuf;
   #endif
}

char *numtohex(int64_t n, int nDigits=1, char *pszBuf=0) {
   return numtostr(n, nDigits, pszBuf, 0x10);
}

int execHexdump(void *pcoi, uint8_t *pBuf, uint32_t nBufSize, int iHighOff=-1, int iHighLen=0)
{
   FILE *fout = stdout;
 
   int64_t ntotal = 0;

   uint8_t *pBufCur = pBuf;
   int nBufRem = (int)nBufSize;

   int64_t nHexDumpOff = nGlblHexDumpOff;

   int lOutLen2=0, lIndex=0, lIndex2=0;
   int lRelPos=0;
   uint8_t *pTmp = 0;
   uint8_t ucTmp;
   uint8_t abBlockBuf[1000];

   int nbpl  = bGlblHexDumpWide ?  32 : 16; // bytes per line
   int itext = bGlblHexDumpWide ?  75 : 39; // text begin
   int ioffs = bGlblHexDumpWide ? 108 : 56; // offset begin
   int ieol  = ioffs + 20;
 
   int64_t  nTotalMax = 0;
   if (nGlblHexDumpLen > 0)
        nTotalMax = nHexDumpOff + nGlblHexDumpLen;

   bool bNoBlockTrail = 0;
   bool bNoLineTrail  = 0;

   uint32_t uiCharPos = 0;

   while (1)
   {
      int nread = 0;
      if (pBuf) {
         if (nBufRem <= 0)
            break;
         if (nbpl < nBufRem) nread = nbpl;
         else                nread = nBufRem;
         memcpy(abBlockBuf, pBufCur, nread);
         pBufCur += nread;
         nBufRem -= nread;
      }
      if (nread <= 0) break;
      pTmp = abBlockBuf;

      int lOutLen = nread;
 
      // dump a full or partial output line?
      if (nTotalMax > 0) {
         int64_t nTotalRemain = nTotalMax - ntotal;
         if (lOutLen > nTotalRemain)
            lOutLen = nTotalRemain;
         if (lOutLen <= 0)
            break;
      }

      szLineBuf[0] = '\0';
      bool bshort  = 0;
      bool bEOD    = 0;
 
      // last record?
      if (nTotalMax > 0)
         if (ntotal + nread >= nTotalMax)
            bEOD = 1;

      switch (nGlblHexDumpForm)
      {
         case 0:
            break; // fall through

         case 1: { // pure
            for (int i=0; i<lOutLen; i++)
               mystrcatf(szLineBuf,MAX_LINE_LEN,"%02X",pTmp[i]);
            strcat(szLineBuf,"\n");
            bshort = 1;
            break;
         }

         case 2: { // source, hex
            for (int i=0; i<lOutLen; i++)
               mystrcatf(szLineBuf,MAX_LINE_LEN,"0x%02X,",pTmp[i]);
            int iLen = strlen(szLineBuf);
            if (bNoLineTrail || (bEOD && bNoBlockTrail))
               if (iLen > 0 && szLineBuf[iLen-1] == ',')
                  szLineBuf[iLen-1] = '\0';
            strcat(szLineBuf,"\n");
            bshort = 1;
            break;
         }

         case 3: { // source, dec
            for (int i=0; i<lOutLen; i++)
               mystrcatf(szLineBuf,MAX_LINE_LEN,"%u,",(uint32_t)pTmp[i]);
            int iLen = strlen(szLineBuf);
            if (bNoLineTrail || (bEOD && bNoBlockTrail))
               if (iLen > 0 && szLineBuf[iLen-1] == ',')
                  szLineBuf[iLen-1] = '\0';
            strcat(szLineBuf,"\n");
            bshort = 1;
            break;
         }

         case 4: { // flat, filtering control characters, skipping binary
            for (int i=0; i<lOutLen; i++) {
               uint8_t c = pTmp[i];
               if (!c) {
                  int nRemain = lOutLen - i;
                  mystrcatf(szLineBuf,MAX_LINE_LEN," [binary, skipping %u bytes]\n", nRemain);
                  break;
               }
               else
               if (c < 0x20 && (c != '\r' && c != '\n' && c != '\t'))
                  continue; // skip control characters except LF, TAB
               else
                  mystrcatf(szLineBuf,MAX_LINE_LEN,"%c",(char)c);
            }
            bshort = 1;
            break;
         }

         case 5: // forum
         case 6: // minimal
         {
         // strcpy(szLineBuf, "    -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- # ---------------- ----");
            strcpy(szLineBuf, "                                                    #                      ");
                           //  01234567890123456789012345678901234567890123456789012345678901234567890123456789
                           //            1         2         3          4        5         6         7
            for (int i=0; i<lOutLen; i++) {
               uint8_t c = pTmp[i];
               mystrplot(szLineBuf+4+i*3, 2, "%02X", c);
               if (   (nGlblHexDumpForm==5 && isprint(c)!=0)
                   || (nGlblHexDumpForm==6 && isalnum(c)!=0)
                  )
                  szLineBuf[54+i] = c;
               else
                  szLineBuf[54+i] = '.';
            }
            sprintf(szLineBuf+71, "%04X\n", (int)ntotal);
            bshort = 1;
            break;
         };
      }

      if (bshort)
      {
         // dump short form created above
         fprintf(fout,"%s",szLineBuf);
      }
      else
      {
         // dump full hex format with offset and ascii
         memset(szLineBuf, ' ', ieol);
         memset(szAttrBuf, ' ', ieol);
         szLineBuf[ieol] = '\0';
         szAttrBuf[ieol] = '\0';
 
         szLineBuf[1] = '>';
         szAttrBuf[1] = 'i';
 
         char *pszHexOff = numtohex(ntotal, 8);
         strcpy(&szLineBuf[ioffs], pszHexOff);
         // adds zero terminator after offset info!
         int ieol = strlen(szLineBuf);
         szAttrBuf[ieol] = '\0';
 
         lOutLen2 = lOutLen;
 
         for(lIndex = 2, lIndex2 = itext, lRelPos = 0;
             lOutLen2;
             lOutLen2--, lIndex += 2, lIndex2++
            )
         {
            ucTmp = *pTmp++;
 
            sprintf(szLineBuf + lIndex, "%02X ", (unsigned short)ucTmp);
 
            if(isprint(ucTmp))
               szAttrBuf[lIndex2] = 'i';  // mark printable text
            else
               ucTmp = '.'; // nonprintable char

            // optional: highlight given area
            if (iHighOff != -1) {
               uiCharPos = ntotal + lRelPos;
               if (uiCharPos >= iHighOff && uiCharPos < iHighOff+iHighLen) {
                  szAttrBuf[lIndex+0] = 'e';
                  szAttrBuf[lIndex+1] = 'e';
                  szAttrBuf[lIndex2 ] = 'e';
               }
            }

            szLineBuf[lIndex2] = ucTmp;

            if (!(++lRelPos & 3))     // extra blank after 4 bytes
            {  lIndex++; szLineBuf[lIndex+2] = ' '; }
         }
 
         if (!(lRelPos & 3)) lIndex--;
 
         szLineBuf[lIndex  ]   = '<';
         szLineBuf[lIndex+1]   = ' ';
         szAttrBuf[lIndex ]   = 'i';
 
         printf("%s\n", szLineBuf);
      }

      ntotal += (int64_t)nread;

      if (bEOD)
         break;
   }

   return 0;
}

int main(int argc, char *argv[])
{
   if (argc < 2)
   {
       printf("xed inputfile /from/to/ [/from2/to2/] [options]\n"
             "\n"
             "   a stream text editor using SFK Simple Expressions.\n"
             "\n"
             "   THIS IS A DUMMY WITHOUT EXPRESSION FUNCTIONALITY,\n"
             "   just to test integration into your project.\n"
             "   No matter what /from/to/ expressions are given,\n"
             "   it always replaces word \"foo\" by \"bar\".\n"
             "\n"
             "   options\n"
             "      -tofile f    write output to file f. do not use +tofile\n"
             "                   chaining as it splits data into text lines.\n"
             "      -rawterm     on output to terminal do not strip codes\n"
             "                   below 32. Null bytes are always stripped.\n"
             "      -blank       add extra blank line on every result output\n"
             "                   if no totext is given (uses [all]\\n\\n then)\n"
             "      -crlf, -lf   for file headers and default totext: force\n"
             "                   crlf or lf line endings instead of default\n"
             );
      printf("   examples\n"
             "      xed in.txt \"/foo*bar/goo/\" -tofile out.txt\n"
             "         read from file in.txt, replace \"foo\" and \"bar\" with\n"
             "         up to 4000 characters inbetween by the word \"goo\".\n"
             "         write output to a file out.txt.\n"
             );
   }

   struct MainOptions cs;
   memset(&cs, 0, sizeof(cs));

   SFKMatch::globalInit();

   int iDir = 1;

   #ifdef _WIN32
   strcpy(cs.szeol, "\r\n");
   #else
   strcpy(cs.szeol, "\n");
   #endif

   {
      SFKMatch *apExp = 0;
      int     iExp  = 0;
      bool  bHexDump = 0;
      bool  bIncomplete = 0;
      bool  bExtractMode = 0;
      char *pszInFile = 0;
      int   iShowPreState = 0;

      int  nMaxExp   = argc + 10; // approx.
      char cHighAttr = 't';

      cs.rawterm = 0;
      cs.placeholder = 0;

      SFKMatch::setOutFNCallback(cbSFKMatchOutFN);

      char szDefaultTo[100];
      szDefaultTo[0] = '\0';

      int iStart=iDir;
      for (int ipass=0; ipass<2; ipass++)
      {
       for (iDir=iStart; iDir<argc; iDir++)
       {
         char *pszArg  = argv[iDir];
         char *pszParm = 0;
         if (haveParmOption(argv, argc, iDir, "-tofile", &pszParm)) {
            if (!pszParm) return 9;
            cs.tomask = pszParm;
            cs.tomaskfile = 1;
            continue;
         }
         if (strBegins(pszArg, "-dump")) {
            bHexDump = 1;
            continue;
         }
         if (haveParmOption(argv, argc, iDir, "-fill", &pszParm)) {
            if (!pszParm) return 9;
            cs.placeholder = *pszParm;
            continue;
         }
         if (!strcmp(pszArg, "-rawterm")) {
            cs.rawterm = 1;
            continue;
         }
         if (strBegins(pszArg, "-show")) {
            char *psz = pszArg+5;
            int iwhat = 0;
            if (strBegins(psz, "part"))  iwhat |= 1;
            if (strBegins(psz, "best"))  iwhat |= 2;
            if (strBegins(psz, "list"))  iwhat |= 4;
            if (strBegins(psz, "all" ))  iwhat |= 7;
            if (iwhat & 1) {
               cs.showpre = 1;
               iShowPreState = 1;
            }
            if (iwhat & 2)
               cs.showpost = 1;
            if (iwhat & 4)
               cs.showlist = 1;
            continue;
         }
         if (!strcmp(pszArg, "-case"))      {
            SFKMatch::setGlobalOption(SFKMatchUseCase, 1);
            continue; 
         }
         if (!strcmp(pszArg, "-extract"))      {
            bExtractMode = 1;
            SFKMatch::setGlobalOption(SFKMatchExtract, 1);
            continue;
         }
         if (!strcmp(pszArg, "-blank")) {
            sprintf(szDefaultTo, "[all]%s%s", cs.szeol, cs.szeol);
            continue;
         }
         if (!strcmp(pszArg, "-verbose"))   { cs.verbose = 1; continue; }
         if (!strcmp(pszArg, "-verbose=2")) { cs.verbose = 2; continue; }

         if (!strncmp(pszArg, "-", 1)) {
            return 9+sfkerr("unknown option: %s\n", pszArg);
         }

         if (!ipass)
            continue;

         // process non-option keywords:
         if (!pszInFile) {
            pszInFile = pszArg;
            continue;
         }

         if (iShowPreState==1) {
            iShowPreState = 2;
            printf("Pat.  Range  MaxOut Memory FromText\n");
         }

         // e.g. /foo*bar/[all]/
         // TODO: use reperr
         if (strlen(pszArg) < 4)
            return 9+sfkerr("pattern too short: %s\n", pszArg);

         strcopy(szLineBuf, pszArg);
         char cLimit = szLineBuf[0];
         char *pszfs = szLineBuf+1;
         char *pszfe = pszfs;
         while (*pszfe!=0 && *pszfe!=cLimit)
            pszfe++;
         if (!*pszfe)
            return 9+sfkerr("missing end of from part: %s\n", pszArg);

         *pszfe++ = '\0';
         char *pszts = pszfe;
         char *pszte = pszts;
         while (*pszte!=0 && *pszte!=cLimit)
            pszte++;
         if (!*pszte)
         {
            if (bExtractMode!=0 && pszte==pszts) {
               if (!szDefaultTo[0])
                  sprintf(szDefaultTo, "[all]%s", cs.szeol);
               pszts = szDefaultTo;
            } else {
               bIncomplete = 1;
               if (!cs.showpre) {
                  cs.showpre = 1;
                  printf("[/.../to/ part(s) incomplete, showing info:]\n");
                  //      12345 123456 123456 123456
                  printf("Pat.  Range  MaxOut Memory FromText\n");
               }
            }
         } else {
            *pszte++ = '\0';
         }

         if (!apExp) {
            if (!(apExp = new SFKMatch[nMaxExp]))
               return 9+sfkerr("out of memory\n");
         }

         int iSubRC = apExp[iExp].init(pszfs,pszts,0);


         if (iSubRC)
            return 9;

         iExp++;
       }
      }

      SFKMatch::setGlobalOption(SFKMatchTrace, cs.verbose);

      if (bIncomplete) {
         printf("[complete all /from/to/ patterns to continue]\n");
         return 5;
      }

      // now that all expressions are prepared allocate buffers
      if (SFKMatch::provideBuffer())
         return 9;

      uint8_t *pInText = 0;   // actual text data
      int64_t  nInSize = 0;

      uint8_t *pOutText= 0;
      int64_t  nOutSize= 0;

      // ------- load input -------

      char szEOL[10];
      int  iEOL = 1;
      strcpy(szEOL, "\n");

      // for [file.*] evaluation:
      strcopy(szGlblCurrentInputFile, pszInFile ? pszInFile : (char *)"");

      if (pszInFile)
      {
         if (!(pInText = loadBinaryFile(pszInFile, nInSize)))
            sfkerr("cannot load: %s", pszInFile);
         if (!pInText)
            return 9;
      }

      if (cs.verbose)
         printf("xed uses %d input bytes: %s\n", (int)nInSize, dataAsTrace(pInText,mymin(60,nInSize)));

      nOutSize = 0;

      // ------- search/replace -------

      bool   bAnyMatch=0,bAnyLocalMatch=0;
      int    iLocalMatches=0;

      uint8_t *pSrcCur=0,*pSrcMax=0,*pDstCur=0,*pDstMax=0;
      bool   bStart=1;

      bAnyLocalMatch = 0;
      iLocalMatches  = 0;

      for (int ipass=0; ipass<2; ipass++)
      {
         pSrcCur = pInText;
         pSrcMax = pInText + nInSize;

         if (ipass)
         {
            if (!(pOutText = new uint8_t[nOutSize+100]))
               return 9+sfkerr("out of memory");
            pDstCur = pOutText;
            pDstMax = pOutText + nOutSize;
         }

         bStart = 1;

         while (pSrcCur <= pSrcMax)
         {
            int nRemain = pSrcMax - pSrcCur;

            int iStepped = 0;

            for (int ipat=0; ipat<iExp; ipat++)
            {
               int iMatchRC = 0;
               int nSrcLen = nRemain;
               if ((iMatchRC = apExp[ipat].matches(pSrcCur, nSrcLen, bStart, 1))) {
                  if (cs.verbose > 2)
                     printf("%d = check offset=%d ipat=%d maxlen=%d\n",
                        iMatchRC, (int)(pSrcCur-pInText), ipat, nRemain);
                  continue;
               }

               bAnyMatch = 1;
               bAnyLocalMatch = 1;
               if (ipass)
                  iLocalMatches++;

               if (cs.verbose > 2)
                  printf("%d = check offset=%d ipat=%d maxlen=%d\n",
                     iMatchRC, (int)(pSrcCur-pInText), ipat, nRemain);

               uint8_t *pObjOut=0;
               int nDstLen=0,iSubRC=0;

               if (!(pObjOut = apExp[ipat].renderOutput(nDstLen, iSubRC)))
                  return 9+sfkerr("output rendering failed");

               int iSizeDiff = nDstLen - nSrcLen;

               if (cs.verbose > 1)
               {
                  char szInfoBuf1[100],szInfoBuf2[100];
                  printf("xed: pattern=%d hit at index=%d size=%+d from=\"%s\"... out=\"%s\"...\n",
                     ipat+1, (int)(pSrcCur-pInText), iSizeDiff,
                     dataAsTrace(pSrcCur,mymin(nRemain,16),szInfoBuf1,sizeof(szInfoBuf1)),
                     dataAsTrace(pObjOut,mymin(nDstLen,16),szInfoBuf2,sizeof(szInfoBuf2))
                     );
               }

               if (ipass) {
                  // replace data
                  memcpy(pDstCur, pObjOut, nDstLen);
                  pDstCur += nDstLen;
               } else {
                  // just count data
                  nOutSize += nDstLen;
               }

               // on zero length hit, continue with further patterns
               if (nSrcLen == 0)
                  continue;

               iStepped += nSrcLen;
               pSrcCur  += nSrcLen;

               bStart = 0;

               // restart with first pattern
               break;

            }  // endfor patterns

            bStart = 0;

            if (pSrcCur == pSrcMax)
               break;   // zero length run for [eod]

            if (!iStepped)
            {
               if (!bExtractMode) {
                  if (ipass) {
                     *pDstCur = *pSrcCur;
                     pDstCur++;
                  } else {
                     nOutSize++;
                  }
               }

               pSrcCur++;
            }

         }  // endwhile pSrcCur
 
      }  // endfor pass

      *pDstCur++ = '\0'; // safety

      // ------- handle output -------

      pSrcCur = pOutText;
      pSrcMax = pOutText + nOutSize;

      bool bFileDone = 0;
      if (cs.tomask && cs.tomaskfile)
      {
         saveFile(cs.tomask, pOutText, nOutSize);
         bFileDone = 1;
      }

      if (bHexDump)
      {
         execHexdump(0, pOutText, nOutSize);
      }
      else if (!bFileDone)
      {
         // to terminal
         while (pSrcCur < pSrcMax)
         {
            int iCopy = pSrcMax - pSrcCur;
            if (iCopy > MAX_LINE_LEN)
                iCopy = MAX_LINE_LEN;

            // with windows, we have to strip all CR
            // as LF will be auto expanded to CRLF.

            int iDst=0;
            for (int iSrc=0; iSrc<iCopy; iSrc++)
            {
               uint8_t cSrc = (uint8_t)pSrcCur[iSrc];
               #ifdef _WIN32
               if (cSrc == '\r')
                  continue;
               #endif
               if (cSrc == 0) {
                  if (cs.placeholder)
                     cSrc = cs.placeholder;
                  else
                     continue;
               }
               if (cs.rawterm==0 && cSrc<32) {
                  // strip BEL, BS, EOF
                  switch (cSrc) {
                     case '\t':
                     case '\n':
                     case 0x1B:
                        break;
                     default:
                        if (cs.placeholder) {
                           cSrc = cs.placeholder;
                           break;
                        }
                        continue;
                  }
               }
               szLineBuf[iDst] = (char)cSrc;
               iDst++;
            }

            szLineBuf[iDst] = '\0';

            if (iDst > 0)
               printf("%s\n", szLineBuf);

            pSrcCur += iCopy;
         }
      }


      // cleanup
      if (apExp   ) delete [] apExp;
      if (pOutText) delete [] pOutText;
      if (pInText)  delete [] pInText;

      SFKMatch::shutdown();
   }

   return 0;
}

