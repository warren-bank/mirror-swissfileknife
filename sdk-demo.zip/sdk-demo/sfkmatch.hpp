/*
   SFKMatch - the Swiss File Knife Simple Expression Parser
   --------------------------------------------------------

   Copyright (c) 2014 by Stahlworks Technologies, www.stahlworks.com.
   All rights reserved.
   
   Licensed for use in closed source projects.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

#ifndef _STDINT_H
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned       uint32_t;
typedef long long      int64_t;
#endif

#define MAX_LINE_LEN               4096
#define SFKMATCH_DEFAULT_MAXLEN    MAX_LINE_LEN
#define SFKMATCH_MAX_LITERAL_SIZE  MAX_LINE_LEN

extern int SFKMatchDefaultMaxLen;
extern int SFKMatchByteWildCards;

// optional user implemented callback to expand
//    [file.name]    as current input filename with path
//    [file.relname] as current input filename without path
//    [file.path]    as path of current input filename
//    [file.base]    as relname without .extension
//    [file.ext]     as input filename .extension
// Function 1: check command syntax
// Function 2: create output
// RC  0 : OK all done
// RC 10 : invalid parameters
// RC 11 : unknown command
// RC 12 : missing or invalid data, cannot execute command
typedef int (*SFKMatchOutFNCallback_t)(int iFunction, char *pMask, int *pIOMaskLen, uint8_t **ppOut, int *pOutLen);

#define SFKMATCH_WITHATTRIB  1  // support text color attributes

enum ESFKMatchOptions
{
   SFKMatchUseCase  = 1,  // bool: case-sensitive search (not default)
   SFKMatchXChars   = 2,  // bool: treat \xnn as characters (not default)
   SFKMatchExtract  = 3,  // bool: skip unmatched data in output
   SFKMatchLitAttr  = 4,  // char: literal highlight attribute, or 0 for none
   SFKMatchTrace    = 5,  // int : print sfkmatch traces to terminal
   SFKMatchXText    = 6   // bool: running xtext (not relevant in sdk)
};

/*
   How to use:
   ===========

   -  once at program start:
         SFKMatch::globalInit();

   -  then set SFKMatch options like
         SFKMatch::bClUseCase = 1;
      to set case sensitive search

   -  then set optional "file." evaluation callback like
         SFKMatch::setOutFNCallback(cbSFKMatchOutFN);

   -  then allocate SFKMatch objects by
         pobj = new SFKMatch();
         pobj->init(pszFromText,pszToText,0);

   -  after ALL SFKMatch objects are initialized, call
         SFKMatch::provideBuffer()
      to allocated internal shared buffers using the size
      of the largest SFKMatch object.

   -  then call pobj->matches(pszInputText, iInputLength,
                  bIsFirstBlockOfInputData, bIsLastBlockOfInput)
      if will return ZERO (0) if there is a MATCH.
      it will return NON ZERO if there is NO MATCH or an ERROR.
      ERRORS are signaled by a return value of 9 or higher.

   -  if there is a match, call pobj->renderOutput(iOutLen, iSubRC)
      which will return the reformatted ToText output, it's length
      and an extra return code in case of errors.

   -  once at program end:
         SFKMatch::shutdown();

   SFKMatch uses shared buffers which are NOT thread safe.
   If you are using multiple threads in your program
   then use SFKMatch only in one of these threads.

   Short usage example:

      SFKMatch omatch;
      omatch.init("*[white]foo[white]*", "[part5]");
      omatch.provideBuffer();
 
      char *pszIn = "the foo bar";
 
      int iInLen = strlen(pszIn);
      int irc = omatch.matches((uint8_t*)pszIn, iInLen, 0, 1, 0);
 
      int iOutLen = 0;
      int iOutRC  = 0;
      char *pszOut = (char*)omatch.renderOutput(iOutLen, iOutRC);
 
      printf("match RC %d with output: \"%s\"\n", irc, pszOut ? pszOut : "?");
 
      SFKMatch::shutdown(); // at program end

   To use SFKMatch objects with color attributes:

      -  init SFKMatch objects with SFKMATCH_WITHATTRIB

      -  on every call to matches() supply pOptAttr pointing to a text
         with same size as pSrcData, containing self defined color
         codes like 'e','i','r','g','b' etc.

      -  renderOutput will then also render an attribute buffer
         that can be accessed by outAttr()

   Pattern Expansion Priorities:
      1. Start, End, LStart, LEnd, EOL
      2. Literals
      3. whitelist classes: byte of, bytes of ...
      4. blacklist classes: byte, chars, bytes, bytes not ...
*/

class SFKMatch
{
public:
   SFKMatch   ( );
  ~SFKMatch   ( );
 
static
   void  globalInit     ( ), // call once at program start
         setGlobalOption(enum ESFKMatchOptions e, int iValue);

   int   init           (char *pszFromMask, char *pszToMask, int nFlags=0);
                             // call once per object. Flags can be SFKMATCH_WITHATTRIB

   int   isValid        ( ); // returns 1 if matches() can be called

static
   int   provideBuffer  ( ), // MUST call this before first use of matches()
         shutdown       ( ); // MUST be called at program end
   int   matches        (uint8_t *pSrcData, int &rIOLength,
                         int bStart, int bLastRecord, char *pOptAttr=0);
                             // returns ZERO (0) on a MATCH.
                             // returns NON ZERO 1...8 on a MISMATCH.
                             // returns 9 or higher on ERRORS.
  uint8_t *renderOutput (int &rOutLength, int &rRC);
                             // sets rOutLength and rRC
  char    *outAttr      ( ); // only if color attributes are used

   int   verify         (int iPattern);
   // print console warnings on template problems

   int   objectMemory   ( );
   int   staticMemory   ( );
   int   objectFromRange( ); // from part may find up to so many bytes
   int   objectToRange  ( ); // to part may render up to so many bytes

char
   *recentPartInfo      ( ),
   *recentPrioInfo      ( );

   // optionally set user implemented function to evaluate file... parts
static int
    setOutFNCallback    (SFKMatchOutFNCallback_t pFN);

#ifndef SFKMATCH_IMPORTED
static char
   *dataAsTrace         (void *pAnyData, int iDataSize, char *pszBuf=0, int iMaxBuf=0);
#endif // SFKMATCH_IMPORTED


static SFKMatchOutFNCallback_t
   pClOutFN;
};

int sfkerr(const char *pszFormat, ...);
int sfkinf(const char *pszFormat, ...);

