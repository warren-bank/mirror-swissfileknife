/*
   SFKMatch - the Swiss File Knife Simple Expression Parser
   --------------------------------------------------------

   Copyright (c) 2014 by Stahlworks Technologies, www.stahlworks.com.
   All rights reserved.

   Licensed for use in closed source projects.
*/

#ifndef SFKMATCH_IMPORTED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

#ifdef _WIN32
 #include <windows.h>
 #define vsnprintf _vsnprintf
 #define snprintf  _snprintf
 const char  glblPathChar = '\\';
#else
 const char  glblPathChar = '/';
#endif

#include "sfkmatch.hpp"

#define mymin(a,b) ((a<b)?(a):(b))

// print error to terminal
int sfkerr(const char *pszFormat, ...)
{
   char szErrBuf[200];

   va_list argList;
   va_start(argList, pszFormat);
   ::vsnprintf(szErrBuf, sizeof(szErrBuf)-10, pszFormat, argList);
   szErrBuf[sizeof(szErrBuf)-10] = '\0';

   if (!strchr(szErrBuf, '\n'))
      strcat(szErrBuf, "\n");

   fprintf(stderr, "error: %s", szErrBuf);

   return 0;
}

// print info to terminal
int sfkinf(const char *pszFormat, ...)
{
   char szErrBuf[200];

   va_list argList;
   va_start(argList, pszFormat);
   ::vsnprintf(szErrBuf, sizeof(szErrBuf)-10, pszFormat, argList);
   szErrBuf[sizeof(szErrBuf)-10] = '\0';

   if (!strchr(szErrBuf, '\n'))
      strcat(szErrBuf, "\n");

   fprintf(stdout, "%s", szErrBuf);

   return 0;
}

char *SFKMatch::dataAsTrace(void *pAnyData, int iDataSize, char *pszBuf, int iMaxBuf)
{
   static char szBuf[300];

   if (!pszBuf)
   {
      pszBuf = szBuf;
      iMaxBuf = sizeof(szBuf);
   }
 
   uint8_t *pSrcCur = (uint8_t *)pAnyData;
   uint8_t *pSrcMax = pSrcCur + iDataSize;
 
   char *pszDstCur = pszBuf;
   char *pszDstMax = pszBuf + iMaxBuf - 20;
 
   while (pSrcCur < pSrcMax && pszDstCur < pszDstMax)
   {
      uint8_t uc = *pSrcCur++;
 
      if (isprint((char)uc))
      {
         *pszDstCur++ = (char)uc;
         continue;
      }

      // convert binary to {hex}
      sprintf(pszDstCur, "{%02X}", uc);
      pszDstCur += 4;
   }
 
   *pszDstCur = '\0';
 
   return pszBuf;
}

class NoCaseText
{
public:
   NoCaseText    ( );
   void reinit (bool bISO);

   inline  char lowerChar ( char c) { return aClLowerTab[(uint8_t)c]; }
   inline uint8_t lowerUChar(uint8_t c) { return (uint8_t)aClLowerTab[(uint8_t)c]; }
   inline uint8_t mapChar   (uint8_t c, uint8_t bCase) { return bCase ? c : (uint8_t)aClLowerTab[(uint8_t)c]; }
   void  setStringToLower(char *psz);

   char aClLowerTab[256+10];
};

NoCaseText glblNoCase;

NoCaseText::NoCaseText()
{
   reinit(1); // default
}

void NoCaseText::reinit(bool bISO)
{
   memset(aClLowerTab, 0, sizeof(aClLowerTab));

   for (uint32_t u1=0; u1<256; u1++)
   {
      uint8_t u2 = (uint8_t)u1;

      if (u1 >= 0x41 && u1 <= 0x5A)    // A-Z
         u2 += 0x20U;    // -> a-z

      if (bISO)
      {
         // ISO 8859-1 special character lowercase mapping
         if (u1 >= 0xC0 && u1 <= 0xDE)    // special characters
            if (u1 != 0xD7 && u1 != 0xDF) // NOT these two
               u2 += 0x20U; // e.g. � -> �
      }

      aClLowerTab[u1] = (char)u2;
   }
}

void NoCaseText::setStringToLower(char *psz)
{
   for (int i=0; psz[i]; i++)
   {
      psz[i] = aClLowerTab[(uint8_t)psz[i]];
   }
}

inline void sfkSetBit(uint8_t *pField, uint32_t iBit)
{
   pField[iBit>>3] |= (1U << (iBit & 7));
}

inline uint8_t sfkGetBit(uint8_t *pField, uint32_t iBit)
{
   return (pField[iBit>>3] & (1U << (iBit & 7))) ? 1 : 0;
}

// RC : 0 == match, <> 0 == no match.
// Not suitable for sorting algorithms.
int sfkmemcmp2(uint8_t *psrc1, uint8_t *psrc2, int64_t nlen, bool bGlobalCase, uint8_t *pFlags)
{
   if (bGlobalCase)
      return memcmp(psrc1, psrc2, nlen);

   int idiff=0;

   // optim: compare last character first.
   // requires at least a 2-char phrase.
   if (nlen > 1)
   {
      uint8_t bCase = pFlags ? sfkGetBit(pFlags,nlen-1) : 0;
      idiff =     glblNoCase.mapChar(psrc1[nlen-1],bCase)
               -  glblNoCase.mapChar(psrc2[nlen-1],bCase);
      if (idiff)
         return idiff;
   }

   uint8_t bCase;

   for (int i=0; i<nlen; i++)
   {
      bCase = pFlags ? sfkGetBit(pFlags,i) : 0;
      idiff =     glblNoCase.mapChar(psrc1[i],bCase)
               -  glblNoCase.mapChar(psrc2[i],bCase);
      if (idiff)
         break;
   }

   return idiff;
}

// RC : 0 == match, <> 0 == no match.
// Not suitable for sorting algorithms.
int sfkmemcmp(uint8_t *psrc1, uint8_t *psrc2, int64_t nlen, bool bcase)
{
   if (bcase)
      return memcmp(psrc1, psrc2, nlen);

   int64_t i=0, idiff=0;

   // optim: compare last character first.
   // requires at least a 2-char phrase.
   if (nlen > 1)
   {
      idiff =     glblNoCase.lowerUChar(psrc1[nlen-1])
               -  glblNoCase.lowerUChar(psrc2[nlen-1]);
      if (idiff)
         return idiff;
   }

   for (; i<nlen; i++)
   {
      idiff =     glblNoCase.lowerUChar(psrc1[i])
               -  glblNoCase.lowerUChar(psrc2[i]);

      if (idiff)
         break;
   }

   return idiff;
}

bool myisxdigit(char c) {
   if (c >= '0' && c <= '9') return 1;
   if (c >= 'a' && c <= 'f') return 1;
   if (c >= 'A' && c <= 'F') return 1;
   return 0;
}

int getTwoDigitHex(char *psz)
{
   char szHex[10];

   if (!*psz) return -1;
   szHex[0] = tolower(*psz++);
   if (!myisxdigit(szHex[0])) return -1;

   if (!*psz) return -1;
   szHex[1] = tolower(*psz++);
   if (!myisxdigit(szHex[1])) return -1;

   szHex[2] = '\0';

   return (int)strtoul(szHex,0,0x10);
}

#else

#define sfkerr perr
#define sfkinf pinf

#endif // SFKMATCH_IMPORTED


SFKMatchOutFNCallback_t SFKMatch::pClOutFN = 0;

int SFKMatchDefaultMaxLen = SFKMATCH_DEFAULT_MAXLEN;
int SFKMatchByteWildCards = 0;



void SFKMatch::globalInit( ) { }
void SFKMatch::setGlobalOption(enum ESFKMatchOptions e, int iValue) { }
SFKMatch::SFKMatch( ) { }
SFKMatch::~SFKMatch( ) { }
int SFKMatch::setOutFNCallback(SFKMatchOutFNCallback_t pFN) { return 0; }
int SFKMatch::init(char *pszFromMask, char *pszToMask, int nFlags) { return 0; }
int SFKMatch::provideBuffer( ) { return 0; }
int SFKMatch::shutdown( ) { return 0; }

char szDummyResult[500];
int iDummyResultLength = 0;

int SFKMatch::matches(uint8_t *pSrcData, int &rIOLength, int bStart, int bLastRecord, char *pSrcAttr)
{
   if (rIOLength < 3)
      return 1; // no match

   if (strncmp((char*)pSrcData, "foo", 3))
      return 1;

   strcpy(szDummyResult, "bar");
   iDummyResultLength = 3;

   rIOLength = 3;

   return 0; // match
}

uint8_t *SFKMatch::renderOutput(int &rOutLength, int &rRC)
{
   rRC = 0;
   rOutLength = iDummyResultLength;
   return (uint8_t*)szDummyResult;
}

