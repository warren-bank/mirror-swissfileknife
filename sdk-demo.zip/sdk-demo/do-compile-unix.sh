g++ -oxed xed.cpp sfkmatch.cpp
