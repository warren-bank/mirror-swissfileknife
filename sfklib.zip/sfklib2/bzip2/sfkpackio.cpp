
#include "sfkpackio.hpp"

// IN: bPack
int sfkPackStart(SFKPackStream *p)
{
   int ret = 0;

   if (p->bzip2)
   {
      bz_stream *pstrm = new bz_stream;
      memset(pstrm, 0, sizeof(bz_stream));

      if (p->bPack)
      {
         ret = BZ2_bzCompressInit(pstrm, 3, 1, 30);
      }
      else
      {
         ret = BZ2_bzDecompressInit(pstrm, 0, 0);
      }

      p->pstream = pstrm;
   }
   else
   {
      z_stream *pstrm = new z_stream;
      memset(pstrm, 0, sizeof(z_stream));

      if (p->bPack)
      {
         int windowBits = 15;
         int GZIP_ENCODING = 16;
 
         ret = deflateInit2(pstrm,
                  Z_BEST_COMPRESSION,
                  Z_DEFLATED,
                  windowBits | GZIP_ENCODING,
                  8,
                  Z_DEFAULT_STRATEGY);
      }
      else
      {
         ret = inflateInit2(pstrm, 16+MAX_WBITS);
      }

      p->pstream = pstrm;
   }

   return ret;
}

// IN: pin, nin, pout, nout
// CONV: if nin returned is >0 call again
int sfkPackProc(SFKPackStream *p, int bLastBlock, int bReloop)
{
   int ret = 0;

   if (p->bzip2)
   {
      bz_stream *pstrm = (bz_stream *)p->pstream;

      if (p->bPack)
      {
         pstrm->next_in   = (char*)p->pin;
         pstrm->avail_in  = p->nin;
         pstrm->next_out  = (char*)p->pout;
         pstrm->avail_out = p->nout;
 
         ret = BZ2_bzCompress(pstrm, bLastBlock ? BZ_FINISH : BZ_RUN);

         if (ret == BZ_STREAM_END)
            ret = Z_STREAM_END;
 
         p->nout = p->nout - pstrm->avail_out;
         p->nin  = pstrm->avail_in;
      }
      else
      {
         if (bReloop == 0)
         {
            pstrm->next_in   = (char*)p->pin;
            pstrm->avail_in  = p->nin;
         }
 
         pstrm->next_out  = (char*)p->pout;
         pstrm->avail_out = p->nout;
 
         ret = BZ2_bzDecompress(pstrm);

         if (ret == BZ_STREAM_END)
            ret = Z_STREAM_END;

         p->nout = p->nout - pstrm->avail_out;
         p->nin  = pstrm->avail_in;
      }
   }
   else
   {
      z_stream *pstrm = (z_stream *)p->pstream;

      if (p->bPack)
      {
         pstrm->next_in   = p->pin;
         pstrm->avail_in  = p->nin;
         pstrm->next_out  = p->pout;
         pstrm->avail_out = p->nout;
 
         ret = deflate(pstrm, bLastBlock ? Z_FINISH : Z_PARTIAL_FLUSH);
 
         p->nout = p->nout - pstrm->avail_out;
         p->nin  = pstrm->avail_in;
      }
      else
      {
         if (bReloop == 0)
         {
            pstrm->next_in   = p->pin;
            pstrm->avail_in  = p->nin;
         }
 
         pstrm->next_out  = p->pout;
         pstrm->avail_out = p->nout;
 
         ret = inflate(pstrm, Z_NO_FLUSH);
 
         p->nout = p->nout - pstrm->avail_out;
         p->nin  = pstrm->avail_in;
      }
   }

   return ret;
}

int sfkPackEnd(SFKPackStream *p)
{
   int ret = 0;

   if (p->bzip2)
   {
      bz_stream *pstrm = (bz_stream *)p->pstream;

      if (p->bPack)
         BZ2_bzCompressEnd(pstrm);
      else
         BZ2_bzDecompressEnd(pstrm);
   }
   else
   {
      z_stream *pstrm = (z_stream *)p->pstream;
 
      if (p->bPack)
         ret = deflateEnd(pstrm);
      else
         ret = inflateEnd(pstrm);
   }

   p->pstream = 0;

   return ret;
}

#ifdef TESTCOMP

#include <stdarg.h>

#ifdef _WIN32
 typedef __int64 num;
#else
 typedef long long num;
#endif

static int perr(const char *pszFormat, ...)
{
   va_list argList;
   va_start(argList, pszFormat);
   char szBuf[1024];
   ::vsprintf(szBuf, pszFormat, argList);
   fprintf(stderr, "error: %s", szBuf);
   return 0;
}

#define CHUNK 16384
#define USE_GZIP

num iTotalIn=0,iTotalOut=0;

int def(FILE *source, FILE *dest, int level)
{
    int ret, flush;
    unsigned have;
    z_stream strm;
    unsigned char in[CHUNK];
    unsigned char out[CHUNK];

    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;

    #ifdef USE_GZIP
    int windowBits = 15;
    int GZIP_ENCODING = 16;
    ret = deflateInit2 (&strm,
            Z_DEFAULT_COMPRESSION,
            Z_DEFLATED,
            windowBits | GZIP_ENCODING,
            8,
            Z_DEFAULT_STRATEGY);
    #else
    ret = deflateInit(&strm, level);
    #endif

    if (ret != Z_OK)
        return ret;

    do
    {
        strm.avail_in = fread(in, 1, CHUNK, source);
        if (ferror(source)) {
            (void)deflateEnd(&strm);
            return Z_ERRNO;
        }
        flush = feof(source) ? Z_FINISH : Z_NO_FLUSH;
        strm.next_in = in;

        // printf("Read %d eof=%d\n", strm.avail_in, flush);
        iTotalIn += strm.avail_in;

        do
        {
            strm.avail_out = CHUNK;
            strm.next_out = out;
            ret = deflate(&strm, flush);    /* no bad return value */
            have = CHUNK - strm.avail_out;

            // printf("Write %d\n", have);
            if (fwrite(out, 1, have, dest) != have || ferror(dest))
            {
                (void)deflateEnd(&strm);
                return Z_ERRNO;
            }
            iTotalOut += have;

        } while (strm.avail_out == 0);

    } while (flush != Z_FINISH);

    (void)deflateEnd(&strm);
    return Z_OK;
}

int inf(FILE *source, FILE *dest)
{
    int ret;
    unsigned have;
    z_stream strm;
    unsigned char in[CHUNK];
    unsigned char out[CHUNK];

    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;

    #ifdef USE_GZIP
    ret = inflateInit2(&strm, 16+MAX_WBITS);
    #else
    ret = inflateInit(&strm);
    #endif

    if (ret != Z_OK)
        return ret;

    do
    {
        strm.avail_in = fread(in, 1, CHUNK, source);
        if (ferror(source)) {
            (void)inflateEnd(&strm);
            return Z_ERRNO;
        }
        if (strm.avail_in == 0)
            break;

        strm.next_in = in;
        // printf("Read %d\n", strm.avail_in);
        iTotalIn += strm.avail_in;

        do
        {
            strm.avail_out = CHUNK;
            strm.next_out = out;
            ret = inflate(&strm, Z_NO_FLUSH);
            // printf("Infl %d rc %d\n",CHUNK - strm.avail_out,ret);
            switch (ret) {
            case Z_NEED_DICT:
                ret = Z_DATA_ERROR;     /* and fall through */
            case Z_DATA_ERROR:
            case Z_MEM_ERROR:
                (void)inflateEnd(&strm);
                return ret;
            }
            have = CHUNK - strm.avail_out;

            if (fwrite(out, 1, have, dest) != have || ferror(dest)) {
                (void)inflateEnd(&strm);
                return Z_ERRNO;
            }
            iTotalOut += have;

        } while (strm.avail_out == 0);

    } while (ret != Z_STREAM_END);

    (void)inflateEnd(&strm);

    return ret == Z_STREAM_END ? Z_OK : Z_DATA_ERROR;
}

int execPackFile(FILE *pin, FILE *pout, bool bPack, bool bzip2, char *pszFilename)
{
   int iInBufSize  = 100000;
   int iOutBufSize = 100000;

   char *pInBuf  = new char[iInBufSize+100];
   char *pOutBuf = new char[iOutBufSize+100];

   if (!pInBuf || !pOutBuf)
      return 9+perr("outofmem\n");

   int nLastDoneMB = 0;

   SFKPackStream ostrm;
   memset(&ostrm, 0, sizeof(ostrm));

   ostrm.bPack = bPack;
   ostrm.bzip2 = bzip2;

   sfkPackStart(&ostrm);

   bool bLastBlock = 0, bReloop = 0;
   int  nRead = 0, isubrc = 0;

   int irc = 0;

   while (1)
   {
      if (bReloop == 0)
      {
         int iMaxRead = iInBufSize;
         nRead  = fread(pInBuf, 1, iMaxRead, pin);
         if (nRead < 1)
            break;
         if (nRead < iMaxRead)
            bLastBlock = 1;
 
         iTotalIn += nRead;
 
         ostrm.pin  = (uchar*)pInBuf;
         ostrm.nin  = nRead;
      }

      ostrm.pout = (uchar*)pOutBuf;
      ostrm.nout = iOutBufSize;

      isubrc = sfkPackProc(&ostrm, bLastBlock, bReloop);

      if (isubrc > 1)
      {
         perr("extract error %d\n",isubrc);
         irc = isubrc;
         break;
      }

      bReloop = (ostrm.nin > 0) ? 1 : 0;

      if (ostrm.nout > 0) {
         if (fwrite(pOutBuf, 1, ostrm.nout, pout) < ostrm.nout) {
            perr("cannot fully write, disk full\n");
            irc = 9;
            break;
         }
      }
      iTotalOut += ostrm.nout;

      if (bPack && bLastBlock)
         break;

      int iDoneMB = iTotalIn/1000000;
      int iOutMB  = iTotalOut/1000000;
      if (iDoneMB != nLastDoneMB)
      {
         nLastDoneMB = iDoneMB;
         printf("%05d/%05d mb %s %s\r",
            iDoneMB, iOutMB, bPack ? "pack":"unpk", pszFilename);
      }
   }

   sfkPackEnd(&ostrm);

   delete [] pInBuf;
   delete [] pOutBuf;

   return irc;
}

/*
cl -DTESTCOMP -omycomp.exe sfkpack.cpp
*/

int main(int argc, char *argv[])
{
   if (argc<4)
   {
      printf("usage: comp c in.dat out.gz\n"
             "       comp d in.gz  out.dat\n");
      return 0;
   }

   char *pszMode    = argv[1];
   char *pszInFile  = argv[2];
   char *pszOutFile = argv[3];

   int err = 0;
   int bcomp = 0;
   int bzip2 = 0;

   if (!strcmp(pszMode, "c"))
      bcomp = 1;
   else
   if (!strcmp(pszMode, "d"))
      bcomp = 0;
   else
   if (!strcmp(pszMode, "bc"))
      { bcomp = 1; bzip2 = 1; }
   else
   if (!strcmp(pszMode, "bd"))
      { bcomp = 0; bzip2 = 1; }
   else
      return 9+perr("wrong mode\n");

   FILE *fin = fopen(pszInFile,"rb");
   if (!fin)
      return 9+perr("cannot read\n");

   FILE *fout=fopen(pszOutFile,"wb");
   if (!fout)
      return 9+perr("cannot write\n");

   #if 1
   err = execPackFile(fin, fout, bcomp, bzip2, pszInFile);
   #else
   if (bcomp)
      err = def(fin, fout, Z_DEFAULT_COMPRESSION);
   else
      err = inf(fin, fout);
   #endif

   fclose(fout);
   fclose(fin);

   if (err > 0)
      printf("rc %d\n",err);

   #ifdef _WIN32
   printf("Done from %I64d to %I64d bytes.\n", iTotalIn, iTotalOut);
   #else
   printf("Done from %lld to %lld bytes.\n", iTotalIn, iTotalOut);
   #endif

   return 0;
}

#endif

