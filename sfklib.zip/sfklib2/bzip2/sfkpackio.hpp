#ifndef SFKPICIO_HPP
#define SFKPICIO_HPP

#ifndef uint
 typedef unsigned int  uint;
#endif
#ifndef uchar
 typedef unsigned char uchar;
#endif

extern uint *(*sfkPicAllocCallback)(int nWords);

struct SFKPackStream
{
   int    bPack;
   int    bzip2;

   uchar *pin;
   int    nin;
   uchar *pout;
   int    nout;

   void  *pstream;
};

int sfkPackStart(SFKPackStream *p);

int sfkPackProc(SFKPackStream *p, int bLastBlock, int bReloop);

int sfkPackEnd(SFKPackStream *p);

#endif
