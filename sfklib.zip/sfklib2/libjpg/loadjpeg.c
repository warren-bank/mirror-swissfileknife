
#include "cdjpeg.h"		/* Common decls for cjpeg/djpeg applications */
#include "jversion.h"		/* for version message */

#include <stdio.h>

#include "jpeglib.h"

#include <setjmp.h>

#define uchar unsigned char
#define ulong unsigned long
#define bool  unsigned char

struct tga_dest_struct
{ 
   struct djpeg_dest_struct pub; /* public fields */ 
   char *iobuffer;               /* physical I/O buffer */ 
   JDIMENSION buffer_width;      /* width of one row */ 
};

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */

  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */

METHODDEF(void)
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We could postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}

// load JPEG from FILE
unsigned char *loadjpeg(char *pszFileName, int *pWidth, int *pHeight)
{
   struct jpeg_decompress_struct cinfo;
   struct my_error_mgr jerr;
   struct tga_dest_struct *dest;
   FILE *fin;
   long num_scanlines;
   unsigned char *pbuf;
   long nFlatSize = 0, iLines = 0;
   uchar *pFlat = 0;
 
   fin = fopen(pszFileName, "rb");
   if (!fin) return 0;

   cinfo.err = jpeg_std_error(&jerr.pub);

   // disable the use of exit():
   jerr.pub.error_exit = my_error_exit;
   /* Establish the setjmp return context for my_error_exit to use. */
   if (setjmp(jerr.setjmp_buffer)) {
    /* If we get here, the JPEG code has signaled an error.
     * We need to clean up the JPEG object, close the input file, and return.
     */
    jpeg_destroy_decompress(&cinfo);
    fclose(fin);
    return 0;
   }

   jpeg_create_decompress(&cinfo);
 
   jpeg_stdio_src(&cinfo, fin);
 
   jpeg_read_header(&cinfo, TRUE);

   if (cinfo.image_width > 5000 || cinfo.image_height > 5000)
      { fclose(fin); return 0; }

   dest = (struct tga_dest_struct *)
       (*cinfo.mem->alloc_small) ((j_common_ptr) &cinfo, JPOOL_IMAGE, 
               SIZEOF(struct tga_dest_struct)); 
   dest->pub.start_output  = 0; // start_output_tga; 
   dest->pub.finish_output = 0; // finish_output_tga;  
   jpeg_calc_output_dimensions(&cinfo);
   dest->buffer_width = cinfo.output_width * cinfo.output_components; 
   dest->iobuffer = (char *) 
     (*cinfo.mem->alloc_small) ((j_common_ptr) &cinfo, JPOOL_IMAGE, 
             (size_t) (dest->buffer_width * SIZEOF(char))); 
   dest->pub.buffer = (*cinfo.mem->alloc_sarray) 
     ((j_common_ptr) &cinfo, JPOOL_IMAGE, dest->buffer_width, (JDIMENSION) 1); 
   dest->pub.buffer_height = 1; 

   *pWidth  = (int)cinfo.output_width;
   *pHeight = (int)cinfo.output_height;

   nFlatSize = dest->buffer_width * cinfo.output_height;
   // pFlat = new uchar[nFlatSize];
   pFlat = (uchar*)malloc(nFlatSize);
   if (!pFlat) { fclose(fin); return 0; }

   jpeg_start_decompress(&cinfo);

   iLines = 0;
   while (cinfo.output_scanline < cinfo.output_height) 
   {
      num_scanlines = jpeg_read_scanlines(
         &cinfo,
         dest->pub.buffer,
         dest->pub.buffer_height
         );
      pbuf = dest->pub.buffer[0];
      memcpy(pFlat + dest->buffer_width * iLines, dest->pub.buffer[0], dest->buffer_width);
      iLines++;
   }

   jpeg_finish_decompress(&cinfo);
   jpeg_destroy_decompress(&cinfo);
 
   fclose(fin);
 
   return pFlat;
}

METHODDEF(void)
mem_init_source (j_decompress_ptr cinfo) { }

METHODDEF(boolean)
mem_fill_input_buffer (j_decompress_ptr cinfo)
{
   // if this is called, there is a problem
   // with the loaded file data.
   return FALSE; 
}

METHODDEF(void)
mem_skip_input_data (j_decompress_ptr cinfo, long num_bytes)
{
  struct jpeg_source_mgr *src = cinfo->src;

  if (src->bytes_in_buffer < num_bytes)
     return;

  src->next_input_byte += (size_t) num_bytes;
  src->bytes_in_buffer -= (size_t) num_bytes;
}

METHODDEF(void)
mem_term_source (j_decompress_ptr cinfo) { }

int iGlblJpegErrno = 0;
char szGlblJpegErrStr[100];

// load JPEG from a MEMORY BLOCK
unsigned char *loadmemjpeg(void *pBlock, int nBytes, int *pWidth, int *pHeight, long *pComponents)
{
   struct jpeg_decompress_struct cinfo;
   struct my_error_mgr jerr;
   struct tga_dest_struct *dest;
   struct jpeg_source_mgr mymgr;
   long num_scanlines;
   unsigned char *pbuf;
   long nFlatSize = 0, iLines = 0;
   uchar *pFlat = 0;

   iGlblJpegErrno = 0;
   szGlblJpegErrStr[0] = '\0';
 
   cinfo.err = jpeg_std_error(&jerr.pub);

   jerr.pub.error_exit = my_error_exit;

   if (setjmp(jerr.setjmp_buffer))
   {
      jpeg_destroy_decompress(&cinfo);
      iGlblJpegErrno = 1;
      strcpy(szGlblJpegErrStr, "decoding error");
      return 0;
   }

   jpeg_create_decompress(&cinfo);
 
   cinfo.src = &mymgr;

   // just one block with the jpg file data
   mymgr.next_input_byte = (JOCTET*)pBlock;
   mymgr.bytes_in_buffer = nBytes;

   // most of these are dummies
   mymgr.init_source       = mem_init_source;
   mymgr.fill_input_buffer = mem_fill_input_buffer;
   mymgr.skip_input_data   = mem_skip_input_data;
   mymgr.resync_to_restart = jpeg_resync_to_restart;
   mymgr.term_source       = mem_term_source;
 
   jpeg_read_header(&cinfo, TRUE);

   *pWidth      = (int)cinfo.image_width;
   *pHeight     = (int)cinfo.image_height;
   *pComponents = (int)cinfo.num_components;

   if (cinfo.image_width > 10000 || cinfo.image_height > 10000) {
      iGlblJpegErrno = 2;
      sprintf(szGlblJpegErrStr, "too large (%dx%d)", cinfo.image_width, cinfo.image_height);
      return 0;
   }
   if (   cinfo.num_components != 1 
       && cinfo.num_components != 3
       && cinfo.num_components != 4
      )
   {
      iGlblJpegErrno = 3;
      sprintf(szGlblJpegErrStr, "invalid color components (%d)", cinfo.num_components);
      return 0;
   }

   dest = (struct tga_dest_struct *)
       (*cinfo.mem->alloc_small) ((j_common_ptr) &cinfo, JPOOL_IMAGE, 
               SIZEOF(struct tga_dest_struct)); 

   dest->pub.start_output  = 0; // start_output_tga;
   dest->pub.finish_output = 0; // finish_output_tga;

   jpeg_calc_output_dimensions(&cinfo);

   *pWidth      = (int)cinfo.output_width;
   *pHeight     = (int)cinfo.output_height;
   *pComponents = (int)cinfo.output_components;

   dest->buffer_width = cinfo.output_width * cinfo.output_components; 
   dest->iobuffer = (char *) 
     (*cinfo.mem->alloc_small) ((j_common_ptr) &cinfo, JPOOL_IMAGE, 
             (size_t) (dest->buffer_width * SIZEOF(char))); 
   dest->pub.buffer = (*cinfo.mem->alloc_sarray) 
     ((j_common_ptr) &cinfo, JPOOL_IMAGE, dest->buffer_width, (JDIMENSION) 1); 
   dest->pub.buffer_height = 1; 

   nFlatSize = dest->buffer_width * cinfo.output_height;

   pFlat = (uchar*)malloc(nFlatSize);
   if (!pFlat) {
      iGlblJpegErrno = 4;
      sprintf(szGlblJpegErrStr, "out of memory (%ld)", nFlatSize);
      return 0;
   }

   jpeg_start_decompress(&cinfo);

   iLines = 0;
   while (cinfo.output_scanline < cinfo.output_height) 
   {
      num_scanlines = jpeg_read_scanlines(
         &cinfo,
         dest->pub.buffer,
         dest->pub.buffer_height
         );
      if (num_scanlines < 1) { // safety
         iGlblJpegErrno = 5;
         sprintf(szGlblJpegErrStr, "incomplete decoding (%d/%d)", cinfo.output_scanline, cinfo.output_height);
         free(pFlat);
         return 0;
      }
      pbuf = dest->pub.buffer[0];
      if (pbuf == 0) {
         iGlblJpegErrno = 6;
         sprintf(szGlblJpegErrStr, "incomplete decoding.2 (%d/%d)", cinfo.output_scanline, cinfo.output_height);
         free(pFlat);
         return 0;
      }
      memcpy(pFlat + dest->buffer_width * iLines, dest->pub.buffer[0], dest->buffer_width);
      iLines++;
   }

   jpeg_finish_decompress(&cinfo);
   jpeg_destroy_decompress(&cinfo);
 
   return pFlat;
}
